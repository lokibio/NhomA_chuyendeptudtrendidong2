/**
 * 
 */
package com.example.customelistview.adapter;

import java.util.ArrayList;
import java.util.List;

import com.example.customelistview.R;
import com.example.customelistview.entity.Player;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author Administrator
 *
 */
public class PlayerAdapter extends ArrayAdapter<Player>{
	
	Context mContext;
	ArrayList<Player> mListPlayer = new ArrayList<Player>();

	public PlayerAdapter(Context context, int resource, List<Player> objects) {
		super(context, resource, objects);
		// TODO Auto-generated constructor stub
		
		this.mContext = context;
		this.mListPlayer = new ArrayList<Player>(objects);
	}
	
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View rowView = convertView;
		ViewHolder viewHolder;
		if(rowView == null){
			LayoutInflater inflate = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			rowView = inflate.inflate(R.layout.item_player, null);
			viewHolder = new ViewHolder();
			viewHolder.txtName = (TextView) rowView.findViewById(R.id.txtName);
			viewHolder.txtBirthday = (TextView) rowView.findViewById(R.id.txtBirthday);
			viewHolder.imgAvatar = (ImageView) rowView.findViewById(R.id.imgAvatar);
			viewHolder.imgFlag = (ImageView) rowView.findViewById(R.id.imgFlag);
			rowView.setTag(viewHolder);
		}
		else{
			viewHolder = (ViewHolder) convertView.getTag();
		}
		
		Player player = mListPlayer.get(position);
		viewHolder.txtName.setText(player.getName());
		viewHolder.txtBirthday.setText(player.getBirthday());
		viewHolder.imgAvatar.setImageResource(player.getAvatar());
		viewHolder.imgFlag.setImageResource(player.getFlag());
		
		return rowView;
		
	}


	static class ViewHolder{
		TextView txtName;
		TextView txtBirthday;
		ImageView imgAvatar;
		ImageView imgFlag;
	}

}
