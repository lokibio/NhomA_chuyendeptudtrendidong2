/**
 * 
 */
package com.example.customelistview.entity;

/**
 * @author Administrator
 *
 */
public class Player {
String name;
String birthday;
int avatar;
int flag;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getBirthday() {
	return birthday;
}
public void setBirthday(String birthday) {
	this.birthday = birthday;
}
public int getAvatar() {
	return avatar;
}
public void setAvatar(int avatar) {
	this.avatar = avatar;
}
public int getFlag() {
	return flag;
}
public void setFlag(int flag) {
	this.flag = flag;
}


}
