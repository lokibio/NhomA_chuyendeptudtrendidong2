package com.example.customelistview;

import java.util.ArrayList;

import com.example.customelistview.entity.Player;
import com.example.customelistview.adapter.PlayerAdapter;
import com.example.customelistview.R;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnItemClickListener {

	ArrayList<Player> mListPlayer = new ArrayList<Player>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_main);
		doCreateFakeData();
		ListView listView = (ListView) findViewById(R.id.listView1);
		PlayerAdapter adapter = new PlayerAdapter(MainActivity.this, R.layout.item_player, mListPlayer);
		listView.setAdapter(adapter);
		listView.setOnItemClickListener(MainActivity.this);
	}

	public void doCreateFakeData() {

		// Cau thu 1
		Player p1 = new Player();
		p1.setName("Benh Vien 1");
		p1.setBirthday("Dia Chi Benh Vien 1");
		p1.setAvatar(R.drawable.mot);
		p1.setFlag(R.drawable.details);

		// Cau thu 2
		Player p2 = new Player();
		p2.setName("Benh Vien 2");
		p2.setBirthday("Dia Chi Benh Vien 2");
		p2.setAvatar(R.drawable.hai);
		p2.setFlag(R.drawable.details);

		// Cau thu 3
		Player p3 = new Player();
		p3.setName("Benh Vien 3");
		p3.setBirthday("Dia Chi Benh Vien 3");
		p3.setAvatar(R.drawable.ba);
		p3.setFlag(R.drawable.details);

		mListPlayer.add(p1);
		mListPlayer.add(p2);
		mListPlayer.add(p3);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		switch (arg2) {
		case 0:
			Toast.makeText(MainActivity.this, "Option 1 Clicked", Toast.LENGTH_LONG).show();
			break;
		case 1:
			Toast.makeText(MainActivity.this, "Option 2 Clicked", Toast.LENGTH_LONG).show();
			break;
		case 2:
			Toast.makeText(MainActivity.this, "Option 3 Clicked", Toast.LENGTH_LONG).show();
			break;
		default:
			Toast.makeText(MainActivity.this, "Greater than 3 Option Clicked", Toast.LENGTH_LONG).show();
			break;
		}
	}

}
